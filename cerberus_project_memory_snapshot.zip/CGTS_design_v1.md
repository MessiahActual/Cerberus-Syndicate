# Cerberus Global Terrain System (CGTS)

## Objective
Merge MSFS-style global streaming terrain with DCS-style tactical accuracy.

## Layers:
1. Real-World Base (satellite + DEM)
2. Procedural Enhancements (biomes, detail LOD)
3. Combat Zones (manual or AI-placed)
4. Infantry Detail Layer (cover, micro terrain)
5. Weather + Environmental Dynamics

## Streaming:
- Supports full globe or cached zones
- Seamless tactical drop-in LOD
- Terrain-aware AI pathing + LOS

## Infantry Support:
- High-res terrain within 100m of player
- Enterable buildings, breaching paths
- Dynamic cover, weather reactions