# OB RIO Protocols – Goose AI

## Voice Command Categories:
- Targeting: "lock," "scan," "track," "ripple fire"
- Navigation: "mark nav point," "map zoom," "scan in IR"
- Prep Commands: "prepare carrier launch," "ready landing gear"
- Coordination: "hand off target," "request datalink contact"
- Callouts: "target 3 o'clock, low," "spike incoming," "Fox 3"

## Modes:
- Full-Immersion Advanced Mode
- Simplified Mode for Casual Users