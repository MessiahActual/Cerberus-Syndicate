# IRON SHIELD – SAM Command Overlay

## Purpose:
Control all SAMs and radar assets from a single CerberusNet-linked interface.

## Features:
- Drag to deploy or command batteries
- Radar cone display
- Voice command to OB: "Activate north SAM net"
- AI fallback routines