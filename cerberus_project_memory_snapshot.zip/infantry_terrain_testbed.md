# Infantry Terrain Testbed (UE5)

## Objective:
Create UE5 simulation terrain with:
- Realistic walking, prone, cover interaction
- Dynamic AI cover logic
- Procedural town with breaching mechanics

## Tools:
- Lyra sample base
- Nanite terrain
- OSM map injection